//
//  ViewController.swift
//  BlueApp
//
//  Created by Li Bai on 9/12/19.
//  Copyright © 2019 Li Bai. All rights reserved.
//

import UIKit
import CoreBluetooth
import BRHJoyStickView
import JoystickView
import WebKit
import UICircularProgressRing


extension Bundle {
    
    /**
     Locate an inner Bundle generated from CocoaPod packaging.
     
     - parameter name: the name of the inner resource bundle. This should match the "s.resource_bundle" key or
     one of the "s.resoruce_bundles" keys from the podspec file that defines the CocoPod.
     - returns: the resource Bundle or `self` if resource bundle was not found
     */
    func podResource(name: String) -> Bundle {
        guard let bundleUrl = self.url(forResource: name, withExtension: "bundle") else { return self }
        return Bundle(url: bundleUrl) ?? self
    }
}

let BLE_UART_Service_CBUUID = CBUUID(string: "6e400001-b5a3-f393-e0a9-e50e24dcca9e")
let BLE_UARTRX_Characteristic_CBUUID = CBUUID(string: "6e400002-b5a3-f393-e0a9-e50e24dcca9e")
let BLE_UARTTX_Characteristic_CBUUID = CBUUID(string: "6e400003-b5a3-f393-e0a9-e50e24dcca9e")
var  connectStatus = false
let delaytime = 0.0
let diffx = 2
let diffy = 2
var txCharacteristic : CBCharacteristic?
var rxCharacteristic : CBCharacteristic?
var peripheralUARTMonitor : CBPeripheral?
var turn:Float = 0.5
var txturn:Float = 0.5
var turnx_prev:Float = 0.0
var speedy_prev:Float  = 0.0
var speed:Float = 0.5
var txspeed:Float = 0.5
var timer: Timer?
var device = ""

class ViewController: UIViewController,  CBCentralManagerDelegate, CBPeripheralDelegate  {

    @IBOutlet weak var mtxtIPAddress: UITextField!
    @IBOutlet weak var btnConnect: UIButton!
    @IBOutlet weak var speedProgress: UICircularProgressRing!
    @IBOutlet weak var turnControlJoy: JoyStickView!
    @IBOutlet weak var turnProgress: UICircularProgressRing!
    @IBOutlet weak var mBlueDeviceName: UILabel!
    @IBOutlet weak var speedControlJoy: JoyStickView!
    @IBOutlet weak var mWebView: WKWebView!
    var centralManager: CBCentralManager?
    @IBOutlet weak var btnSend: UIButton!
    
    
    @IBAction func btnConnectionAction(_ sender: Any) {

        if (connectStatus == false){
            print("try to   connect")
            centralManager?.scanForPeripherals(withServices: [BLE_UART_Service_CBUUID])
            self.btnConnect.isHidden = true
            self.btnConnect.setTitle("Disconnect", for: .normal)
            connectStatus = true
            
        }
        else{
            if peripheralUARTMonitor != nil {
                centralManager?.cancelPeripheralConnection(peripheralUARTMonitor!)
            }
            print("try to  disconnect")
            self.btnConnect.setTitle("Connect", for: .normal)
            mBlueDeviceName.text = ""
            connectStatus = false
        }
    }
    
    @IBAction func btnSendAction(_ sender: Any) {
        print("send")
        let ipaddress:String  = mtxtIPAddress.text!
        print(ipaddress)
        if (ipaddress == ""){
            let myURL = URL(string:"http://www.temple.edu")
            let myRequest = URLRequest(url: myURL!)
            mWebView.load(myRequest)
        }
        else{
            let myURL = URL(string:"http://\(ipaddress):8080/?action=stream")
            print(myURL!)
            let myRequest = URLRequest(url: myURL!)
            mWebView.load(myRequest)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.btnConnect.isHidden = true
        let ipaddress:String = mtxtIPAddress.text!
        // Do any additional setup after loading the view.
        if (ipaddress == ""){
            let myURL = URL(string:"http://www.temple.edu")
            print(myURL!)
            let myRequest = URLRequest(url: myURL!)
            mWebView.load(myRequest)
        }
        else{
            let myURL = URL(string:"http://\(ipaddress):8080/?action=stream")
            let myRequest = URLRequest(url: myURL!)
            mWebView.load(myRequest)
        }
        
        let monitorspeedxy: JoyStickViewXYMonitor = { report in
           // print("\(report.x), \(report.y)")
            if report.y != 0.0 {
                if (Int(abs(speedy_prev - Float(report.y))) > diffy) {
                    
                    let y = report.y/50.0
                    speed = Float(0.5 * y + 0.5)
                    if (speed<0.5){
                        self.speedProgress.innerRingColor = UIColor.red
                    }
                    else{
                        self.speedProgress.innerRingColor = UIColor.green
                    }
                    self.speedProgress.startProgress(to: CGFloat(speed*100), duration:delaytime) {
                        // Do anything your heart desires...
                    }
                    txturn = (turn-0.5)*0.1 + 0.15
                    txspeed = (speed-0.5)*0.1 + 0.15
                    self.writeValue(data:"\(txturn), \(txspeed)")
                }
                speedy_prev = Float(report.y)
                
            }
            else{
                speed = 0.5
                speedy_prev = 0
                self.speedProgress.innerRingColor = UIColor.green
                self.speedProgress.startProgress(to: CGFloat(speed*100), duration: delaytime) {
                    //                   print("Done animating! \(turn), \(speed)")
                    // Do anything your heart desires...
                }
                txturn = (turn-0.5)*0.1 + 0.15
                txspeed = (speed-0.5)*0.1 + 0.15
         //       self.writeValue(data:"\(txturn), \(txspeed)")
            }
            
            
        }
        
        
        let monitorturnxy: JoyStickViewXYMonitor = { report in
            
            
            if report.x != 0.0 {
                
                if (Int(abs(turnx_prev - Float(report.x))) > diffx) {
                    
                    
                    let x = report.x/50.0
                    turn = Float(0.5 * x + 0.5)
                    self.turnProgress.startProgress(to: CGFloat(turn*100), duration: delaytime) {
                        //               print("Done animating! \(turn), \(speed)")
                        // Do anything your heart desires...
                    }
                    txturn = (turn-0.5)*0.1 + 0.15
                    txspeed = (speed-0.5)*0.1 + 0.15
                    self.writeValue(data:"\(txturn), \(txspeed)")
                }
                turnx_prev = Float(report.x)
                //         print(" Speed \(x)， \(y)")
                
            }
            else{
                turn = 0.5
                turnx_prev = 0
                self.turnProgress.startProgress(to: CGFloat(turn*100), duration: delaytime) {
                    //            print("Done animating! \(turn), \(speed)")
                    // Do anything your heart desires...
                }
                txturn = (turn-0.5)*0.1 + 0.15
                txspeed = (speed-0.5)*0.1 + 0.15
              //  self.writeValue(data:"\(txturn), \(txspeed)")
            }
        }
        
        
        let bundle = Bundle(for: JoyStickView.self).podResource(name: "BRHJoyStickView")
        speedControlJoy.baseImage = UIImage(named: "FancyBase", in: bundle, compatibleWith: nil)
        speedControlJoy.handleImage = UIImage(named: "FancyHandle", in: bundle, compatibleWith: nil)
        //speedControlJoy.monitor = .polar(monitor: monitorspeed)
        speedControlJoy.monitor = .xy(monitor: monitorspeedxy)
        
        
        turnControlJoy.baseImage = UIImage(named: "FancyBase", in: bundle, compatibleWith: nil)
        turnControlJoy.handleImage = UIImage(named: "FancyHandle", in: bundle, compatibleWith: nil)
        turnControlJoy.monitor = .xy(monitor: monitorturnxy)
        let centralQueue: DispatchQueue = DispatchQueue(label: "com.uart.centralQueueName", attributes: .concurrent)
        
        centralManager = CBCentralManager(delegate: self, queue: centralQueue)

    }

    
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        
        switch central.state {
            
        case .unknown:
            print("Bluetooth status is UNKNOWN")
        case .resetting:
            print("Bluetooth status is RESETTING")
        case .unsupported:
            print("Bluetooth status is UNSUPPORTED")
        case .unauthorized:
            print("Bluetooth status is UNAUTHORIZED")
        case .poweredOff:
            print("Bluetooth status is POWERED OFF")
        case .poweredOn:
            print("Bluetooth status is POWERED ON")
            DispatchQueue.main.async { () -> Void in
                self.btnConnect.isHidden = false
            }
            
            // STEP 3.2: scan for peripherals that we're interested in
            
        @unknown default:
            break
        } // END switch
        
    } // END func centralManagerDidUpdateState
    
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        //print("look for")
        
        print(peripheral.name!)
        // localname = [advertisementData objectForKey:kCBAdvDataLocalName];

        
        device = advertisementData["kCBAdvDataLocalName"] as! String
        decodePeripheralState(peripheralState: peripheral.state)
        // STEP 4.2: MUST store a reference to the peripheral in
        // class instance variablefdev
        peripheralUARTMonitor = peripheral
        // STEP 4.3: since HeartRateMonitorViewController
        // adopts the CBPeripheralDelegate protocol,
        // the peripheralHeartRateMonitor must set its
        // delegate property to HeartRateMonitorViewController
        // (self)
        peripheralUARTMonitor?.delegate = self
        
        // STEP 5: stop scanning to preserve battery life;
        // re-scan if disconnected
        centralManager?.stopScan()
        
        // STEP 6: connect to the discovered peripheral of interest
        centralManager?.connect(peripheralUARTMonitor!)
        
    } // END func centralManager(... didDiscover peripheral
    
    // STEP 7: "Invoked when a connection is successfully created with a peripheral."
    
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        
        DispatchQueue.main.async { () -> Void in
            print("found service" )
        }
        
        // STEP 8: look for services of interest on peripheral
        peripheralUARTMonitor?.discoverServices([BLE_UART_Service_CBUUID])
        
    } // END func centralManager(... didConnect peripheral
    
    
    
    // STEP 15: when a peripheral disconnects, take
    // use-case-appropriate action
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        
        print("Disconnected!")
        DispatchQueue.main.async { () -> Void in
            
        }
        
        // STEP 16: in this use-case, start scanning
        // for the same peripheral or another, as long
        // as they're HRMs, to come back online
        //centralManager?.scanForPeripherals(withServices: [BLE_UART_Service_CBUUID])
        
    } // END func centralManager(... didDisconnectPeripheral peripheral
    
    
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        
        for service in peripheral.services! {
            
            if service.uuid == BLE_UART_Service_CBUUID {
                
                print("Service: \(service)")
                
                
                // STEP 9: look for characteristics of interest
                // within services of interest
                peripheral.discoverCharacteristics(nil, for: service)
                
            }
            
        }
        
    } // END func peripheral(... didDiscoverServices
    
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        print("charaterstic")
        for characteristic in service.characteristics! {
            print(characteristic)
            
            if characteristic.uuid == BLE_UARTRX_Characteristic_CBUUID {
                
                // STEP 11: subscribe to a single notification
                // for characteristic of interest;
                // "When you call this method to read
                // the value of a characteristic, the peripheral
                // calls ... peripheral:didUpdateValueForCharacteristic:error:
                //
                // Read    Mandatory
                //
                rxCharacteristic = characteristic
                peripheral.readValue(for: characteristic)
                
            }
            
            if characteristic.uuid == BLE_UARTTX_Characteristic_CBUUID {
                
                // STEP 11: subscribe to regular notifications
                // for characteristic of interest;
                // "When you enable notifications for the
                // characteristic’s value, the peripheral calls
                // ... peripheral(_:didUpdateValueFor:error:)
                //
                // Notify    Mandatory
                //
                txCharacteristic = characteristic
                //  print("--------------")
                //  print(txCharacteristic)
                //  print(">>>>>>>>>>>>>>")
                peripheral.setNotifyValue(true, for: characteristic)
                
            }
            
        } // END for
        
    } // END func peripheral(... didDiscoverCharacteristicsFor service
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        print("update")
        if characteristic.uuid == BLE_UARTTX_Characteristic_CBUUID {
            
            // STEP 13: we generally have to decode BLE
            // data into human readable format
            txCharacteristic = characteristic
            DispatchQueue.main.async { () -> Void in
                
                
            } // END DispatchQueue.main.async...
            
        } // END if characteristic.uuid ==...
        
        if characteristic.uuid == BLE_UARTRX_Characteristic_CBUUID {
            
            // STEP 14: we generally have to decode BLE
            // data into human readable format
            rxCharacteristic = characteristic
            DispatchQueue.main.async { () -> Void in
            }
        } // END if characteristic.uuid ==...
        
    } // END func peripheral(... didUpdateValueFor characteristic
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateNotificationStateFor characteristic: CBCharacteristic, error: Error?) {
        print("*******************************************************")
        
        if (error != nil) {
            print("Error changing notification state:\(String(describing: error?.localizedDescription))")
            
        } else {
            print("Characteristic's value subscribed")
        }
        
        if (characteristic.isNotifying) {
            print ("Subscribed. Notification has begun for: \(characteristic.uuid)")
            DispatchQueue.main.async { () -> Void in
                self.btnConnect.isHidden = false
                self.mBlueDeviceName.text = "connect to \(device)"
            }
        }
        
    }
    
    
    
    
    
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil else {
            print("--- Error discovering services: error")
            return
        }
        print("Message sent")
    }
    
    
    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor descriptor: CBDescriptor, error: Error?) {
        guard error == nil else {
            print("Error discovering services: error")
            return
        }
        print("Succeeded!")
    }
    
    
    func decodePeripheralState(peripheralState: CBPeripheralState) {
        
        switch peripheralState {
        case .disconnected:
            print("Peripheral state: disconnected")
            //connectStatus = false
        //btnConnect.setTitle("Connect", for: .normal)
        case .connected:
            print("Peripheral state: connected")
            //connectStatus = true
        //btnConnect.setTitle("Disconnect", for: .normal)
        case .connecting:
            print("Peripheral state: connecting")
        case .disconnecting:
            print("Peripheral state: disconnecting")
        @unknown default: break
        }
        
    } // END func decodePeripheralState(peripheralState
    
    
    
    func writeValue(data: String){
        let valueString = (data as NSString).data(using: String.Encoding.utf8.rawValue)
        //change the "data" to valueString
        if let peripheralUARTMonitor = peripheralUARTMonitor{
            if let rxCharacteristic = rxCharacteristic {
                print("send: \(data)" )
                peripheralUARTMonitor.writeValue(valueString!, for: rxCharacteristic, type: CBCharacteristicWriteType.withResponse)
            }
        }
    }
    
    func writeCharacteristic(val: Int8){
        var val = val
        let ns = NSData(bytes: &val, length: MemoryLayout<Int8>.size)
        peripheralUARTMonitor!.writeValue(ns as Data, for: rxCharacteristic!, type: CBCharacteristicWriteType.withResponse)
    }
    


}

